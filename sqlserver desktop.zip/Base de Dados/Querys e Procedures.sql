use miraisystem

insert into produto values('Teclado', '300', getdate())
update produto set nomeprod = 'Cenoura', quantidade = 250 , dtcultivo = getdate() where idproduto = 1
--DELETE FROM produto WHERE idproduto = @idproduto;
select * from produto

-- Inserir Produto
CREATE PROCEDURE InserirProduto
    @nomeprod VARCHAR(80),
    @quantidade INT,
	@vlrprod float,
    @dtcultivo varchar(30) 
AS
BEGIN
    INSERT INTO produto (nomeprod, quantidade, vlrprod, dtcultivo)
    VALUES (@nomeprod, @quantidade, @vlrprod, @dtcultivo);
END;


EXEC InserirProduto 'Cebola Roxa', 600, 120.22, '2024-10-15 00:06:11.497'

-- Atualizar Produto
CREATE PROCEDURE AtualizarProduto
    @idproduto INT,
    @nomeprod VARCHAR(80),
    @quantidade INT,
	@vlrprod float,
    @dtcultivo varchar(30) 
AS
BEGIN
    UPDATE produto
    SET nomeprod = @nomeprod, quantidade = @quantidade, vlrprod = @vlrprod, dtcultivo = @dtcultivo
    WHERE idproduto = @idproduto;
END;

exec AtualizarProduto 1, 'Cenoura Dourada', 550, 210.21, 'Outono'

insert into cliente values('Arthu', '176.614.646-46', '61.868.435/0001-47', 'arthurxxx25@gmail.com','sulista')
update cliente set nomecli = 'Isac', cnpj = '176.614.646-46' , cpf = '61.868.435/0001-47', email = 'isaucbabes@gmail.com', tipocliente = 'PF' where idcliente = 1
--DELETE FROM cliente WHERE idcliente = @idcliente;
select * from cliente

-- Inserir Cliente
CREATE PROCEDURE InserirCliente
    @nomecli VARCHAR(80),
    @cnpj VARCHAR(30),
    @cpf VARCHAR(30),
    @email VARCHAR(50),
    @tipocliente VARCHAR(30)
AS
BEGIN
    INSERT INTO cliente (nomecli, cnpj, cpf, email, tipocliente)
    VALUES (@nomecli, @cnpj, @cpf, @email, @tipocliente);
END;

Exec InserirCliente 'Samuel', '61.868.435/0001-47', '176.614.646-46', 'samemail@gmail.com', 'PJ'

-- Atualizar Cliente
CREATE PROCEDURE AtualizarCliente
    @idcliente INT,
    @nomecli VARCHAR(80),
    @cnpj VARCHAR(30),
    @cpf VARCHAR(30),
    @email VARCHAR(50),
    @tipocliente VARCHAR(30)
AS
BEGIN
    UPDATE cliente
    SET nomecli = @nomecli, cnpj = @cnpj, cpf = @cpf, email = @email, tipocliente = @tipocliente
    WHERE idcliente = @idcliente;
END;

exec AtualizarCliente 1, 'Igor', '61.868.435/0001-47', '176.614.646-46', 'igorteste@gmail.com', 'PJ'
    

-- Inserir Venda
CREATE PROCEDURE InserirVenda
    @idproduto INT,
    @idcliente INT,
    @qntdvenda INT
AS
BEGIN
    DECLARE @vlr FLOAT;

    -- Obter o valor do produto
    SELECT @vlr = vlrprod
    FROM produto
    WHERE idproduto = @idproduto;

    -- Calcular o valor total da venda
    DECLARE @valortotal FLOAT;
    SET @valortotal = @vlr * @qntdvenda;

    -- Inserir a venda
    INSERT INTO venda (vlrvenda, dtvenda, qntdvenda, idproduto, idcliente)
    VALUES (@valortotal, GETDATE(), @qntdvenda, @idproduto, @idcliente);
END;

-- Exemplo de inser��o de venda
EXEC InserirVenda @idproduto = 1, @idcliente = 1, @qntdvenda = 2;

-- Consultar Vendas
CREATE PROCEDURE ConsultarVendas
AS
BEGIN
    SELECT produto.nomeprod AS produtovendido, cliente.nomecli AS cliente, qntdvenda, vlrvenda, dtvenda
    FROM venda
    INNER JOIN produto ON produto.idproduto = venda.idproduto
    INNER JOIN cliente ON cliente.idcliente = venda.idcliente;
END;

Exec ConsultarVendas
