create database miraisystem

use miraisystem;

create table produto(
	idproduto int not null IDENTITY(1,1) PRIMARY KEY,
	nomeprod varchar(80),
	quantidade int,
	vlrprod float,
	dtcultivo varchar(30)
)

create table cliente(
	idcliente int not null IDENTITY(1,1) PRIMARY KEY,
	nomecli varchar(80),
	cnpj varchar(30),
	cpf varchar(30),
	email varchar(50),
	tipocliente varchar(30)
)

CREATE TABLE venda (
	idvenda INT NOT NULL IDENTITY(1,1), 
	vlrvenda FLOAT,
	dtvenda datetime,
	qntdvenda int,
	idproduto INT,
	idcliente INT,
	CONSTRAINT fk_produto FOREIGN KEY (idproduto) REFERENCES produto(idproduto),
	CONSTRAINT fk_cliente FOREIGN KEY (idcliente) REFERENCES cliente(idcliente)
);