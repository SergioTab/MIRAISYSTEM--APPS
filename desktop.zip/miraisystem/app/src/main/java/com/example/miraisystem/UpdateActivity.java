package com.example.miraisystem;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class UpdateActivity extends AppCompatActivity {

    EditText nmprod_input, vlrprod_input, qntdprod_input, dtcultivo_input;
    Button atualizar_button, deletar_button;

    String id, nomeproduto, valorproduto, quantidade, datacultivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        nmprod_input = findViewById(R.id.nmprod_input2);
        vlrprod_input = findViewById(R.id.vlrprod_input2);
        qntdprod_input = findViewById(R.id.qntdprod_input2);
        dtcultivo_input = findViewById(R.id.dtcultivo_input2);
        atualizar_button = findViewById(R.id.atualizar_button);
        deletar_button = findViewById(R.id.deletar_button);

        getAndSetIntentData();

        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setTitle(nomeproduto);
        }

        atualizar_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(UpdateActivity.this);
                nomeproduto = nmprod_input.getText().toString().trim();
                valorproduto = vlrprod_input.getText().toString().trim();
                quantidade = qntdprod_input.getText().toString().trim();
                datacultivo = dtcultivo_input.getText().toString().trim();
                myDB.updateData(id, nomeproduto, valorproduto, quantidade, datacultivo);
            }
        });
        deletar_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog();
            }
        });

    }

    void getAndSetIntentData(){
        if(getIntent().hasExtra("id") && getIntent().hasExtra("nomeproduto") &&
                getIntent().hasExtra("valorproduto") && getIntent().hasExtra("quantidade")
                && getIntent().hasExtra("datacultivo")){

            id = getIntent().getStringExtra("id");
            nomeproduto = getIntent().getStringExtra("nomeproduto");
            valorproduto = getIntent().getStringExtra("valorproduto");
            quantidade = getIntent().getStringExtra("quantidade");
            datacultivo = getIntent().getStringExtra("datacultivo");

            nmprod_input.setText(nomeproduto);
            vlrprod_input.setText(valorproduto);
            qntdprod_input.setText(quantidade);
            dtcultivo_input.setText(datacultivo);
            Log.d("stev", nomeproduto+" "+valorproduto+" "+quantidade+" "+datacultivo);
        }else{
            Toast.makeText(this, "Sem Dados.", Toast.LENGTH_SHORT).show();
        }
    }

    void confirmDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Deletar o produto: " + nomeproduto + " ?");
        builder.setMessage("Certeza que quer deletar o produto: " + nomeproduto + " ?");
        builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(UpdateActivity.this);
                myDB.deleteOneRow(id);
                finish();
            }
        });
        builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }
}