package com.example.miraisystem;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CreateActivity extends AppCompatActivity {

    EditText nmprod_input, vlrprod_input, quantidade_input, dtcultivo_input;
    Button adicionar_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        nmprod_input = findViewById(R.id.nmprod_input);
        vlrprod_input = findViewById(R.id.vlrprod_input);
        quantidade_input = findViewById(R.id.qntdprod_input);
        dtcultivo_input = findViewById(R.id.dtcultivo_input);
        adicionar_button = findViewById(R.id.adicionar_button);
        adicionar_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(CreateActivity.this);
                myDB.adicionarProduto(nmprod_input.getText().toString().trim(),
                        vlrprod_input.getText().toString().trim(),
                        quantidade_input.getText().toString().trim(),
                        dtcultivo_input.getText().toString().trim());
            }
        });
    }
}